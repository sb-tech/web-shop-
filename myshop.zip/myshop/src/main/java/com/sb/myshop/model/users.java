package com.sb.myshop.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class Users implements Serializable{


    private static final long serialVersionUID =1L;

    @Id
    @GeneratedValue
    private int userId;

    @NotEmpty (message = "The customer name must not be null")
    private String userFullName;

    @NotEmpty (message = "The customer email must not be null")
    private String userEmail;
    private String userPhone;

    @NotEmpty (message = "The customer username must not be null")
    private String userName;

    @NotEmpty (message = "The customer password must not be null")
    private String password;

    private boolean enabled;
    private String role;

    
    @OneToOne
    @JoinColumn(name = "shippingAddressId")
    private ShippingAddress shippingAddress;

    @OneToOne
    @JoinColumn(name = "cartId")
    @JsonIgnore
    private Cart cart;