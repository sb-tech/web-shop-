package com.sb.myshop.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class Order implements Serializable{


    private static final long serialVersionUID = 8546649310334411202L;

    @Id
    @GeneratedValue
    private int OrderId;

    @OneToOne
    @JoinColumn(name = "cartId")
    private Cart cart;

    @OneToOne
    @JoinColumn(name = "customerId")
    private Customer customer;

    @OneToOne
    @JoinColumn(name="shippingAddressId")
    private ShippingAddress shippingAddress;

    public int getOrderId() {
        return OrderId;
    }

    public void setCustomerOrderId(int OrderId) {
        this.OrderId = OrderId;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public ShippingAddress getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(ShippingAddress shippingAddress) {
        this.shippingAddress = shippingAddress;
    }
}

