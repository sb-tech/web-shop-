package com.sb.myshop.dao.impl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sb.myshop.dao.OrderDao;
import com.sb.myshop.model.Order;



@Repository
@Transactional
public class OrderDaoImpl implements OrderDao {

    @Autowired
    private SessionFactory sessionFactory;

    public void addOrder(Order order){
        Session session = sessionFactory.getCurrentSession();
        session.saveOrUpdate(order);
        session.flush();
    }

}