package com.sb.myshop;

import org.springframework.stereotype.Controller;


@Controller
public class myContoller {
	
}

