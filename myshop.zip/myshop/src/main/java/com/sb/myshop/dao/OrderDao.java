package com.sb.myshop.dao;

import com.sb.myshop.model.Order;

public interface OrderDao {

    void addOrder(Order order);
}