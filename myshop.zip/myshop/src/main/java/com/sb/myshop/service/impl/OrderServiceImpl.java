package com.sb.myshop.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sb.myshop.dao.OrderDao;
import com.sb.myshop.model.Cart;
import com.sb.myshop.model.CartItem;
import com.sb.myshop.model.Order;
import com.sb.myshop.service.CartService;
import com.sb.myshop.service.OrderService;



@Service
public class OrderServiceImpl implements OrderService{

    @Autowired
    private OrderDao orderDao;

    @Autowired
    private CartService cartService;

    public void addOrder(Order  customerOrder){
        orderDao.addOrder(customerOrder);
    }

    public double getOrderGrandTotal(int cartId){
        double grandTotal = 0;
        Cart cart = cartService.getCartById(cartId);
        List<CartItem> cartItems = cart.getCartItems();

        for (CartItem item : cartItems){
            grandTotal += item.getTotalPrice();
        }

        return grandTotal;
    }


}