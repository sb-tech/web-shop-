package com.sb.myshop.model;
import java.io.*;
@Entity
	public class Cart implements Serializable{

	    private static final long serialVersionUID = 1L;

	    @Id
	    @GeneratedValue
	    private int cartId;

	    @OneToMany(mappedBy = "cart", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	    private List<CartItem> cartItems;

	    @OneToOne
	    @JoinColumn(name = "customerId")
	    @JsonIgnore
	    private Users user;

	    private double grandTotal;


}
