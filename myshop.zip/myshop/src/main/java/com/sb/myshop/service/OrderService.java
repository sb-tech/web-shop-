package com.sb.myshop.service;

import com.sb.myshop.model.Order;

public interface OrderService {

    void addOrder(Order customerOrder);

    double getOrderGrandTotal(int cartId);
}
