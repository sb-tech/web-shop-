package com.sb.myshop.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class shippingaddress implements Serializable{
	
	private static final long serialVersionUID = 1L;


    @Id
    @GeneratedValue
    private int shippingAddressId;
    private String streetName;
    private String apartmentNumber;
    private String city;
    private String state;
    private String country;
    private String zipCode;

    @OneToOne
    private Users user;
	
	

	

}
