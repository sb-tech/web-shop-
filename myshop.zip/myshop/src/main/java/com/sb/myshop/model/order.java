package com.sb.myshop.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class Order implements Serializable{


    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue
    private int orderId;

    @OneToOne
    @JoinColumn(name = "cartId")
    private Cart cart;

    @OneToOne
    @JoinColumn(name = "customerId")
    private Users user;

    @OneToOne
    @JoinColumn(name = "billingAddressId")
    private BillingAddress billingAddress;

    @OneToOne
    @JoinColumn(name="shippingAddressId")
    private ShippingAddress shippingAddress;

	
}
